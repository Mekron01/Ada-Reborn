import time
state = {"startup_time": time.time()}
