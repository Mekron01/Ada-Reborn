def route_input(text):
    return "routed: " + text
