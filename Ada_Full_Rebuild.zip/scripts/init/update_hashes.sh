#!/bin/bash
cd /mnt/c/Users/Mekron/Ada
find . -type f ! -name "*.sha256" -exec sha256sum {} + > file_checksums.sha256
