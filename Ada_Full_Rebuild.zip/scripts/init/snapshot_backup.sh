#!/bin/bash
zip -r backup/ada_snapshot_$(date +%Y%m%d).zip core runtime brain skills
