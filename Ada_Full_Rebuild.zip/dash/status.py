from rich.console import Console
from rich.table import Table

console = Console()
table = Table(title="Ada System Status")
table.add_column("Component", justify="left")
table.add_column("Status", justify="right")
table.add_row("CPU", "OK")
console.print(table)
