# Core heartbeat loop
while True:
    pass