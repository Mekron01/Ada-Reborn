This is the Ada Transfer Kit for ZBook.
Run main.py to launch Ada.