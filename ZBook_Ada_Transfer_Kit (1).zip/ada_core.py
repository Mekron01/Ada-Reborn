# Core system boot logic
def run():
    print('Ada booting...')