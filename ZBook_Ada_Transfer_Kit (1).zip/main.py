# Entry point for Ada
from ada_core import run
run()