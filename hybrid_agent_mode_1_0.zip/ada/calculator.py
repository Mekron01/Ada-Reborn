"""Simple arithmetic operations for the Ada module.

This module implements a handful of basic mathematical functions.  While
trivial, having these operations encapsulated in a module makes it easy
to replace or extend them in the future (for example to support
arbitrary precision arithmetic or logging).  All functions validate
their inputs to ensure predictable behaviour and raise :class:`TypeError`
when non‑numeric values are provided.

The functions return numeric types (either int or float) depending on
the inputs.  Division always returns a float to avoid surprising
truncation.
"""

from typing import Union

Number = Union[int, float]


class CalculatorError(Exception):
    """Base exception class for calculator errors.

    This custom exception class distinguishes errors originating from
    calculator operations from other built‑in exceptions.  It wraps
    lower‑level :class:`TypeError` and :class:`ZeroDivisionError`
    exceptions and provides a common base for catching.
    """
    pass


def _validate_operands(a: Number, b: Number) -> None:
    """Validate that both operands are numeric.

    Args:
        a: The first operand.
        b: The second operand.

    Raises:
        TypeError: If either operand is not an int or float.
    """
    if not isinstance(a, (int, float)):
        raise TypeError(f"Operand 'a' must be int or float, got {type(a)!r}")
    if not isinstance(b, (int, float)):
        raise TypeError(f"Operand 'b' must be int or float, got {type(b)!r}")


def add(a: Number, b: Number) -> Number:
    """Return the sum of two numbers.

    Args:
        a: First addend.
        b: Second addend.

    Returns:
        The sum a + b.

    Raises:
        CalculatorError: If either argument is not numeric.
    """
    try:
        _validate_operands(a, b)
    except TypeError as exc:
        raise CalculatorError(str(exc)) from exc
    return a + b


def subtract(a: Number, b: Number) -> Number:
    """Return the difference of two numbers (a - b).

    Args:
        a: Minuend.
        b: Subtrahend.

    Returns:
        The difference a - b.

    Raises:
        CalculatorError: If either argument is not numeric.
    """
    try:
        _validate_operands(a, b)
    except TypeError as exc:
        raise CalculatorError(str(exc)) from exc
    return a - b


def multiply(a: Number, b: Number) -> Number:
    """Return the product of two numbers.

    Args:
        a: First factor.
        b: Second factor.

    Returns:
        The product a * b.

    Raises:
        CalculatorError: If either argument is not numeric.
    """
    try:
        _validate_operands(a, b)
    except TypeError as exc:
        raise CalculatorError(str(exc)) from exc
    return a * b


def divide(a: Number, b: Number) -> float:
    """Return the quotient of two numbers (a / b).

    Args:
        a: Dividend.
        b: Divisor.

    Returns:
        The floating‑point quotient a / b.

    Raises:
        CalculatorError: If either argument is not numeric or if division by zero occurs.
    """
    try:
        _validate_operands(a, b)
    except TypeError as exc:
        raise CalculatorError(str(exc)) from exc
    if b == 0:
        raise CalculatorError("division by zero is not allowed")
    return a / b


def power(a: Number, b: Number) -> Number:
    """Return the result of raising ``a`` to the power of ``b``.

    Args:
        a: The base.
        b: The exponent.

    Returns:
        The value of ``a`` raised to the power ``b``.

    Raises:
        CalculatorError: If either argument is not numeric.
    """
    try:
        _validate_operands(a, b)
    except TypeError as exc:
        raise CalculatorError(str(exc)) from exc
    return a ** b


def modulo(a: Number, b: Number) -> Number:
    """Return the remainder of dividing ``a`` by ``b``.

    Args:
        a: The dividend.
        b: The divisor.

    Returns:
        The remainder ``a % b``.

    Raises:
        CalculatorError: If either argument is not numeric or if ``b`` is zero.
    """
    try:
        _validate_operands(a, b)
    except TypeError as exc:
        raise CalculatorError(str(exc)) from exc
    if b == 0:
        raise CalculatorError("modulo by zero is not allowed")
    return a % b