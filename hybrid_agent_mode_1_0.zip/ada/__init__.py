# Ada package

"""
The ``ada`` package provides simple arithmetic operations which emulate a
basic calculator.  These functions form the lower‑level computational
building blocks used by other parts of the Hybrid Agent system.  All
functions handle unexpected input gracefully and raise descriptive
exceptions when invalid types are encountered.

Example:

    from hybrid_agent_mode_1_0.ada import calculator
    result = calculator.add(3, 4)  # returns 7
"""

from .calculator import (
    add,
    subtract,
    multiply,
    divide,
    power,
    modulo,
    CalculatorError,
)  # noqa: F401