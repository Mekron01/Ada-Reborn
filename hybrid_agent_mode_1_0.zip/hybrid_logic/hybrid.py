"""Hybrid logic execution utilities.

This module provides an ``execute_hybrid`` function that attempts to
invoke a named operation via an :class:`~hybrid_agent_mode_1_0.orb.object_registry.ObjectRegistry`.
If the name is not registered, the call falls back to built‑in
arithmetic operations from the Ada calculator module.  This illustrates
how disparate components can be composed to provide seamless, flexible
behaviour.

The hybrid logic currently supports four built‑in operations: ``add``,
``subtract``, ``multiply`` and ``divide``.  For any other name, a
``KeyError`` will be raised.
"""

from __future__ import annotations

from typing import Any, Optional

from ..ada import calculator
from ..orb.object_registry import ObjectRegistry


def execute_hybrid(
    name: str,
    *args: Any,
    registry: Optional[ObjectRegistry] = None,
    **kwargs: Any,
) -> Any:
    """Execute an operation by name using a registry or built‑in functions.

    The function first checks whether ``registry`` is provided and
    contains a callable registered under ``name``.  If so, that
    callable is invoked with the supplied arguments.  Otherwise the
    function attempts to resolve ``name`` against the set of built‑in
    operations in :mod:`hybrid_agent_mode_1_0.ada.calculator`.

    Args:
        name: The name of the operation to perform.
        *args: Positional arguments for the operation.
        registry: Optional object registry to search for the named
            operation.  If ``None`` or if the name is not registered,
            built‑in operations will be consulted.
        **kwargs: Keyword arguments for the operation.  Note that
            built‑in operations currently accept only positional
            arguments.

    Returns:
        The result of the operation.

    Raises:
        KeyError: If the operation cannot be found in the registry and
            is not one of the built‑in operations.
        TypeError: If invalid arguments are provided to the underlying
            operation.
    """
    # Attempt to call a registered operation if possible
    if registry is not None:
        try:
            return registry.call(name, *args, **kwargs)
        except KeyError:
            pass  # fall back to built‑in operations

    # Map of built‑in operation names to calculator functions
    builtin_ops = {
        'add': calculator.add,
        'subtract': calculator.subtract,
        'multiply': calculator.multiply,
        'divide': calculator.divide,
        'power': calculator.power,
        'modulo': calculator.modulo,
    }

    if name not in builtin_ops:
        raise KeyError(
            f"Operation '{name}' not found in registry and not a built‑in operation"
        )

    # Built‑in operations should be called with positional args only
    if kwargs:
        raise TypeError(
            "Built‑in operations only accept positional arguments; did you mean to use a registry?"
        )

    func = builtin_ops[name]
    return func(*args)