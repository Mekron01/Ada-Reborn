# Hybrid logic package

"""
The ``hybrid_logic`` package orchestrates interactions between the Ada
calculator and the ORB registry.  It demonstrates how higher‑level
functionality can be composed from lower‑level modules.  Users of this
package can perform registered operations by name and fall back to
built‑in arithmetic functions when a name is not found.

Example:

    from hybrid_agent_mode_1_0.hybrid_logic import hybrid

    # Set up a registry and register a custom operation
    from hybrid_agent_mode_1_0.orb import ObjectRegistry
    registry = ObjectRegistry()
    registry.register('square', lambda x: x * x)

    # Evaluate using the hybrid executor
    result = hybrid.execute_hybrid('square', 5, registry=registry)  # returns 25

"""

from .hybrid import execute_hybrid  # noqa: F401