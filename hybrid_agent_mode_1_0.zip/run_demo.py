"""Demonstration script for the Hybrid Agent Mode 1.0 bundle.

Running this script will exercise the Ada calculator functions,
register custom operations with the ORB registry, and evaluate
operations via the hybrid logic executor.  It can serve both as an
integration test and as a usage example for developers.
"""

from __future__ import annotations

import sys
import os

# Ensure the package can be imported when running this script directly.
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from hybrid_agent_mode_1_0.ada import calculator, CalculatorError
from hybrid_agent_mode_1_0.orb import ObjectRegistry
from hybrid_agent_mode_1_0.hybrid_logic import hybrid


def main() -> int:
    """Execute a series of test operations and print the results."""
    print("--- Ada Calculator ---")
    print("3 + 4 =", calculator.add(3, 4))
    print("10 - 2 =", calculator.subtract(10, 2))
    print("5 * 6 =", calculator.multiply(5, 6))
    print("8 / 2 =", calculator.divide(8, 2))

    # Demonstrate new operations
    print("2 ** 5 =", calculator.power(2, 5))
    print("10 % 3 =", calculator.modulo(10, 3))

    print("\n--- ORB Registry ---")
    registry = ObjectRegistry()
    registry.register('square', lambda x: x * x)
    registry.register('concat', lambda a, b: f"{a}{b}")
    print("square(9) =", registry.call('square', 9))
    print("concat('foo', 'bar') =", registry.call('concat', 'foo', 'bar'))

    print("\n--- Hybrid Logic ---")
    # Use registry for custom operation
    print("hybrid 'square'(7) =", hybrid.execute_hybrid('square', 7, registry=registry))
    # Fall back to built‑in operations
    print("hybrid 'add'(3, 4) =", hybrid.execute_hybrid('add', 3, 4))
    print("hybrid 'multiply'(6, 7) =", hybrid.execute_hybrid('multiply', 6, 7))

    # Handle an unknown operation gracefully
    try:
        hybrid.execute_hybrid('unknown', 1, 2)
    except KeyError as exc:
        print("Caught expected error:", exc)

    # Demonstrate CalculatorError handling
    try:
        calculator.divide(1, 0)
    except CalculatorError as exc:
        print("Caught expected CalculatorError:", exc)

    return 0


if __name__ == '__main__':
    sys.exit(main())