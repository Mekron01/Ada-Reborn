# Hybrid Agent Mode 1.0

This bundle is a clean, self‑contained demonstration of the **Hybrid Agent
Mode 1.0** concept.  It consists of three packages:

* **Ada (`ada`)** – exposes a set of arithmetic operations such as
  `add`, `subtract`, `multiply`, `divide`, `power` and `modulo`.
  All functions perform input validation and wrap errors in a
  custom `CalculatorError` for easier handling.
* **ORB (`orb`)** – implements a simple, thread‑safe object registry.
  You can register callables or objects under arbitrary names and
  invoke them later via `registry.call()`.
* **Hybrid Logic (`hybrid_logic`)** – glues the Ada and ORB components
  together.  The `execute_hybrid()` function looks up an operation in a
  provided registry and falls back to the built‑in Ada functions when
  necessary.

Additionally, a `run_demo.py` script exercises all components and
serves as both a smoke test and a usage example.  To run the
demonstration in a Python environment with this package on the
`PYTHONPATH`, execute:

```bash
python run_demo.py
```

## Installation

This bundle is purely illustrative and does not depend on any external
libraries.  You can run it directly from the unpacked directory or
install it into a Python environment as follows:

```bash
pip install -e .
```

The above command uses [setuptools editable installs](https://pip.pypa.io/en/stable/topics/local-project-installs/#editable-installs) to make the package available without copying files.  Should you wish to produce a distributable wheel, you can add a `setup.py` file and run `pip
wheel .`.

## License

This code is provided for demonstration purposes under the MIT License.