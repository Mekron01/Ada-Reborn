# ORB package

"""
The ``orb`` (Object Registry Broker) package implements a simple
registry/broker pattern.  Objects can be registered under a name and
retrieved later, which allows loose coupling between producers and
consumers.  This minimal implementation is thread‑safe and can be used
as the basis for more advanced remote object brokers.

Example:

    from hybrid_agent_mode_1_0.orb import ObjectRegistry

    registry = ObjectRegistry()
    registry.register('adder', lambda a, b: a + b)
    result = registry.call('adder', 3, 4)  # returns 7
"""

from .object_registry import ObjectRegistry  # noqa: F401