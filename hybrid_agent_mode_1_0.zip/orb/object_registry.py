"""Thread‑safe object registry/broker implementation.

The :class:`ObjectRegistry` class allows clients to register callables or
instances under a string key and then invoke them indirectly.  This
pattern decouples the registration of services from their consumption.

Internally the registry uses a simple dictionary protected by a
``threading.RLock`` to ensure safe concurrent access.  Duplicate keys
overwrite existing values by default, but this behaviour can be
controlled via arguments to :meth:`register`.
"""

from __future__ import annotations

import threading
from typing import Any, Callable, Dict, Iterable, Optional


class ObjectRegistry:
    """A minimal thread‑safe registry for named callables or objects."""

    def __init__(self) -> None:
        #: Lock protecting the internal registry dictionary
        self._lock = threading.RLock()
        #: Internal mapping of names to objects
        self._registry: Dict[str, Any] = {}

    def register(self, name: str, obj: Any, *, overwrite: bool = True) -> None:
        """Register an object or callable under a given name.

        Args:
            name: The unique key for the object.
            obj: The object or callable to register.
            overwrite: If ``True``, allow replacement of an existing entry
                with the same name.  If ``False`` and the name is already in
                use, a :class:`KeyError` will be raised.

        Raises:
            KeyError: If the name is already registered and ``overwrite`` is
                ``False``.
        """
        with self._lock:
            if not overwrite and name in self._registry:
                raise KeyError(f"An object named '{name}' is already registered")
            self._registry[name] = obj

    def unregister(self, name: str) -> None:
        """Remove a previously registered object.

        Args:
            name: The key of the object to remove.

        Raises:
            KeyError: If no object with the given name exists.
        """
        with self._lock:
            if name not in self._registry:
                raise KeyError(f"No object named '{name}' is registered")
            del self._registry[name]

    def get(self, name: str) -> Any:
        """Retrieve a registered object by name.

        Args:
            name: The key of the object to retrieve.

        Returns:
            The registered object.

        Raises:
            KeyError: If no object with the given name exists.
        """
        with self._lock:
            try:
                return self._registry[name]
            except KeyError:
                raise KeyError(f"No object named '{name}' is registered") from None

    def call(self, name: str, *args: Any, **kwargs: Any) -> Any:
        """Invoke a registered callable object by name.

        This method assumes the object registered under ``name`` is
        callable.  It forwards positional and keyword arguments to the
        callable and returns the result.

        Args:
            name: The name of the callable to invoke.
            *args: Positional arguments to pass to the callable.
            **kwargs: Keyword arguments to pass to the callable.

        Returns:
            The result of calling the registered callable with the given
            arguments.

        Raises:
            KeyError: If no callable with the given name exists.
            TypeError: If the registered object is not callable.
        """
        obj = self.get(name)
        if not callable(obj):
            raise TypeError(f"Registered object '{name}' is not callable")
        return obj(*args, **kwargs)

    def keys(self) -> Iterable[str]:
        """Return an iterable of all registered names."""
        with self._lock:
            return list(self._registry.keys())

    def clear(self) -> None:
        """Remove all registered objects from the registry."""
        with self._lock:
            self._registry.clear()