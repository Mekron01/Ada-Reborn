metadata = {
    "name": "command_input",
    "cooldown": 0,
    "priority": 10,
    "tags": ["interactive", "manual"]
}

def run(input=None, **kwargs):
    if not input:
        return "No input received."

    input = input.strip().lower()

    if input == "help":
        return "You can type: shutdown, help, status, or ask me anything."
    elif input == "status":
        return "Ada is running and listening."
    elif "joke" in input:
        return "Why did the AI cross the road? Because it was trained on both sides."
    else:
        return f"Received input: {input}"
