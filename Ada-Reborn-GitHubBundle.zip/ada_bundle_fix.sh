#!/data/data/com.termux/files/usr/bin/bash

echo "=============================="
echo "       ADA BUNDLE FIX         "
echo "=============================="

# Step 1: Fix permissions on all Ada scripts
echo "[+] Fixing file permissions..."
chmod +x ~/ada/*.sh 2>/dev/null
chmod +x ~/ada/scripts/*.sh 2>/dev/null

# Step 2: Move misplaced requirements.txt to ~/ada if it's not already there
if [ ! -f ~/ada/requirements.txt ]; then
    if [ -f ~/Ada-Reborn/requirements.txt ]; then
        echo "[+] Moving requirements.txt to ~/ada..."
        mv ~/Ada-Reborn/requirements.txt ~/ada/
    fi
fi

# Step 3: Activate virtual environment
echo "[+] Activating virtual environment..."
source ~/ada/.venv/bin/activate

# Step 4: Install packages
echo "[+] Installing from requirements.txt..."
pip install -r ~/ada/requirements.txt

echo "[✓] Fix complete."
