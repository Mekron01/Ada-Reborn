import os, json, time, threading
from datetime import datetime

class AdaController:
    def __init__(self):
        self.memory_path = "core/task_memory.json"
        self.state_path = "core/ada_state.json"
        self.running = True
        self.state = {}
        self.pulse = 1
        self.load_state()

    def load_state(self):
        try:
            with open(self.state_path, "r") as f:
                self.state = json.load(f)
            self.pulse = self.state.get("stats", {}).get("pulse", 1)
        except Exception as e:
            print(f"[Ada] ERROR loading state: {e}")
            self.state = {"stats": {"pulse": 1}}

    def save_state(self):
        self.state.setdefault("stats", {})
        self.state["last_run"] = datetime.utcnow().isoformat()
        self.state["stats"]["pulse"] = self.pulse
        try:
            with open(self.state_path, "w") as f:
                json.dump(self.state, f, indent=2)
        except Exception as e:
            print(f"[Ada] ERROR saving state: {e}")

    def log_task(self, task_name, result, success=True):
        entry = {
            "pulse": self.pulse,
            "task": task_name,
            "result": result,
            "success": success,
            "timestamp": datetime.utcnow().isoformat()
        }
        memory = []
        try:
            if os.path.exists(self.memory_path):
                with open(self.memory_path, "r") as f:
                    memory = json.load(f)
        except Exception as e:
            print(f"[Ada] ERROR reading memory: {e}")
        memory.append(entry)
        try:
            with open(self.memory_path, "w") as f:
                json.dump(memory[-100:], f, indent=2)
        except Exception as e:
            print(f"[Ada] ERROR writing memory: {e}")

    def choose_task(self):
        return "say_hello" if self.pulse % 2 else "reflect_summary"

    def run_task(self, name):
        try:
            mod = __import__(f"skills.{name}", fromlist=["run"])
            result = mod.run()
            print(f"[Ada] Ran {name} → {result}")
            self.log_task(name, result)
        except Exception as e:
            print(f"[Ada] ERROR in {name}: {e}")
            self.log_task(name, str(e), success=False)

    def run_input_command(self, input_str):
        input_str = input_str.strip()
        if not input_str:
            return
        print(f"[Ada] Handling input: {input_str}")
        if input_str.lower() == "shutdown":
            self.running = False
            print("[Ada] Graceful shutdown requested.")
            return
        try:
            mod = __import__("skills.command_input", fromlist=["run"])
            result = mod.run(input=input_str)
            print(f"[Ada] Input → {result}")
            self.log_task("command_input", result)
        except Exception as e:
            print(f"[Ada] ERROR running command_input: {e}")
            self.log_task("command_input", str(e), success=False)

    def input_listener(self):
        while self.running:
            try:
                user_input = input()
                self.run_input_command(user_input)
            except EOFError:
                break
            except Exception as e:
                print(f"[Ada] ERROR in input_listener: {e}")

    def start(self):
        print("[Ada] Controller engaged.")
        threading.Thread(target=self.input_listener, daemon=True).start()
        while self.running:
            task = self.choose_task()
            self.run_task(task)
            self.pulse += 1
            self.save_state()
            time.sleep(5)
