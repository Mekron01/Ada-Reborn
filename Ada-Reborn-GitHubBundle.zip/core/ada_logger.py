def log(message, tag="INFO"):
    print(f"[{tag}] {message}")
