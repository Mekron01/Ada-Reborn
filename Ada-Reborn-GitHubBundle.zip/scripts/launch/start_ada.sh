#!/bin/bash
cd /mnt/c/Users/Mekron/Ada
python3 run_ada.py
