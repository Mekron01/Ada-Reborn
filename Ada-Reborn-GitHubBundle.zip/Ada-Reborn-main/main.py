print("Ada main process running. Hello, world.")
