"""Ada enhanced core package.

This package contains core components for the Ada project, including the
main loop, memory handler, persona management, reflex system, skill
loading and high‑level planning (ORB core).  To start the system use
the :class:`~ada_enhanced.main_loop.AdaCore` class:

.. code-block:: python

    from ada_enhanced.main_loop import AdaCore

    core = AdaCore("path/to/config.json")
    core.run()

"""

__all__ = [
    "AdaCore",
    "MemoryHandler",
    "PersonaManager",
    "ReflexCore",
    "OrbCore",
    "SkillLoader",
]