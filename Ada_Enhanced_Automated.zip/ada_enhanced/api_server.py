"""
API server
==========

This module implements a lightweight HTTP API for interacting with the
Ada core.  It is powered by Flask, but falls back gracefully if
Flask is not available.  The API exposes endpoints for querying
memory summaries, searching memory, retrieving the current persona,
switching persona, and listing loaded skills.

Configuration for the API server is provided via the ``api_server``
section of the configuration file:

.. code-block:: json5

    {
      "api_server": {
        "enable": true,
        "host": "127.0.0.1",
        "port": 5000
      }
    }

Running the API server in production environments should include
proper authentication and TLS, which are beyond the scope of this
example.
"""

from __future__ import annotations

import logging
import threading
from typing import Any, Callable

try:
    from flask import Flask, jsonify, request
except ImportError:  # pragma: no cover
    Flask = None  # type: ignore

logger = logging.getLogger(__name__)


def create_app(memory_handler: Any, persona_manager: Any, skill_loader: Any) -> Any:
    """Create a Flask application exposing Ada APIs.

    :param memory_handler: instance of MemoryHandler
    :param persona_manager: instance of PersonaManager
    :param skill_loader: instance of SkillLoader
    :returns: a Flask app
    """
    if Flask is None:
        raise RuntimeError("Flask is not installed; cannot create API server")
    app = Flask(__name__)

    @app.route('/memory/summary', methods=['GET'])
    def memory_summary() -> Any:
        return jsonify(memory_handler.summary())

    @app.route('/memory/search', methods=['GET'])
    def memory_search() -> Any:
        keyword = request.args.get('q', '')
        limit = request.args.get('limit', type=int)
        results = memory_handler.search_events(keyword, limit)
        return jsonify(results)

    @app.route('/persona/current', methods=['GET'])
    def persona_current() -> Any:
        p = persona_manager.get_current()
        return jsonify({"name": p.name, "description": p.description})

    @app.route('/persona/switch', methods=['POST'])
    def persona_switch() -> Any:
        data = request.get_json() or {}
        name = data.get('name')
        if not name:
            return jsonify({"error": "Missing persona name"}), 400
        p = persona_manager.switch_to(name)
        return jsonify({"name": p.name, "description": p.description})

    @app.route('/skills', methods=['GET'])
    def list_skills() -> Any:
        skills = [
            {
                "name": s.metadata.get("name", s.__class__.__name__),
                "description": s.metadata.get("description", ""),
                "priority": s.metadata.get("priority", 100),
            }
            for s in skill_loader.skills
        ]
        return jsonify(skills)

    return app


def run_api_server(memory_handler: Any, persona_manager: Any, skill_loader: Any,
                   host: str = '127.0.0.1', port: int = 5000) -> Callable[[], None]:
    """Start the API server in a separate thread.

    :returns: a callable to stop the server
    """
    if Flask is None:
        logger.warning("Flask not available; API server not started")
        def nop() -> None:
            pass
        return nop
    app = create_app(memory_handler, persona_manager, skill_loader)
    server = threading.Thread(target=lambda: app.run(host=host, port=port), daemon=True)
    server.start()
    logger.info("API server running on %s:%s", host, port)
    def stop_server() -> None:
        # Flask does not provide a native way to stop; rely on process termination
        logger.info("API server stop requested; terminate the process to stop Flask")
    return stop_server