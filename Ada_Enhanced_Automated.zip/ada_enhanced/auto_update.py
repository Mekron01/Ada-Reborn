"""
Auto-update checker
===================

This module provides utilities to check for updates of the Ada project on
GitHub.  It queries the releases API to determine if a newer version
tag exists compared to the current version specified in the
configuration.  Automatic download and installation of updates is
outside the scope of this module; it simply notifies when a newer
version is available.

Usage::

    from ada_enhanced.auto_update import UpdateChecker
    checker = UpdateChecker(current_version="1.0.0", repo="username/ada-project")
    if checker.is_update_available():
        print("New version available", checker.latest_version)
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Optional

try:
    import requests  # type: ignore
except ImportError:  # pragma: no cover
    requests = None  # type: ignore

logger = logging.getLogger(__name__)


class UpdateChecker:
    """Check GitHub for new releases."""

    def __init__(self, current_version: str, repo: str) -> None:
        self.current_version = current_version
        self.repo = repo
        self.latest_version: Optional[str] = None

    def is_update_available(self) -> bool:
        """Return True if a newer version tag is available."""
        if not self.repo or not requests:
            return False
        try:
            url = f"https://api.github.com/repos/{self.repo}/releases/latest"
            resp = requests.get(url, timeout=10)
            if resp.status_code != 200:
                logger.warning("Failed to fetch releases: %s", resp.status_code)
                return False
            data = resp.json()
            tag = data.get("tag_name")
            if tag and tag.lstrip('v') != self.current_version:
                self.latest_version = tag.lstrip('v')
                return True
        except Exception as exc:
            logger.exception("Error checking for updates: %s", exc)
        return False


def run_update_checker(current_version: str, repo: str, interval: int, stop_event: threading.Event) -> None:
    """Background thread to periodically check for updates.

    If a new version is found, a log message is emitted.  This function
    does not perform any download or installation of updates.
    """
    checker = UpdateChecker(current_version, repo)
    while not stop_event.is_set():
        if checker.is_update_available():
            logger.info("New version available: %s", checker.latest_version)
        time.sleep(interval)