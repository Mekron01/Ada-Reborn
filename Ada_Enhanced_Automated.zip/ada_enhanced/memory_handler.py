"""
Memory handler
==============

This module implements a simple long‑term and emotional memory store.  It
provides methods to record events with timestamps, persist them to disk
and retrieve them later.  The underlying storage is a JSON file with
two top‑level keys: ``events`` and ``kv``.  ``events`` stores a list of
time‑stamped text entries, while ``kv`` stores arbitrary key–value
pairs.  The handler caches the store in memory and writes to disk on
explicit save or at program exit.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class MemoryHandler:
    """Persistent memory for events and key–value data."""

    def __init__(self, file_path: str) -> None:
        self.file_path = file_path
        self._lock = threading.RLock()
        self.data: Dict[str, Any] = {"events": [], "kv": {}}
        self._load()

    def _load(self) -> None:
        """Load the memory store from disk if it exists."""
        if not os.path.exists(self.file_path):
            logger.info("Memory file %s not found; starting with empty store", self.file_path)
            # ensure directory exists
            os.makedirs(os.path.dirname(self.file_path), exist_ok=True)
            self.save()
            return
        try:
            with open(self.file_path, "r", encoding="utf-8") as f:
                content = f.read()
                # Strip out lines that begin with // comments
                lines = [line for line in content.splitlines() if not line.strip().startswith("//")]
                self.data = json.loads("\n".join(lines))
            # ensure expected keys exist
            self.data.setdefault("events", [])
            self.data.setdefault("kv", {})
            logger.info("Loaded memory store with %d events", len(self.data["events"]))
        except Exception as exc:
            logger.exception("Failed to load memory file %s: %s", self.file_path, exc)
            # start with empty store on error
            self.data = {"events": [], "kv": {}}

    def save(self) -> None:
        """Persist the in‑memory store to disk."""
        with self._lock:
            try:
                with open(self.file_path, "w", encoding="utf-8") as f:
                    json.dump(self.data, f, indent=2)
                logger.debug("Memory saved to %s", self.file_path)
            except Exception:
                logger.exception("Failed to save memory to %s", self.file_path)

    def add_event(self, text: str) -> None:
        """Append a textual event with a timestamp to the events list."""
        with self._lock:
            event = {"timestamp": int(time.time()), "text": text}
            self.data["events"].append(event)
            logger.debug("Added memory event: %s", event)

    def get_events(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """Retrieve the most recent events.

        :param limit: maximum number of events to return, or ``None`` for all
        :returns: a list of events sorted by timestamp ascending
        """
        with self._lock:
            events = list(self.data["events"])
        events.sort(key=lambda e: e["timestamp"])
        return events[-limit:] if limit else events

    def set(self, key: str, value: Any) -> None:
        """Store a key–value pair in persistent memory."""
        with self._lock:
            self.data["kv"][key] = value
            logger.debug("Set memory key %s", key)

    def get(self, key: str, default: Optional[Any] = None) -> Any:
        """Retrieve a value from persistent memory."""
        with self._lock:
            return self.data["kv"].get(key, default)

    # New search and summary features
    def search_events(self, keyword: str, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """Return events whose text contains the given keyword (case-insensitive).

        :param keyword: substring to search for
        :param limit: maximum number of events to return
        """
        keyword_lower = keyword.lower()
        with self._lock:
            matches = [e for e in self.data.get("events", []) if keyword_lower in e.get("text", "").lower()]
        matches.sort(key=lambda e: e["timestamp"], reverse=True)
        return matches[:limit] if limit else matches

    def summary(self) -> Dict[str, Any]:
        """Generate a basic summary of the memory contents.

        Returns a dictionary containing the total number of events and a list
        of the top five most frequent words (excluding very common stopwords).
        """
        import re
        from collections import Counter

        stopwords = set([
            "the", "and", "of", "to", "a", "in", "is", "it", "you", "for", "on", "with", "at", "by",
            "an", "be", "this", "that", "or", "as", "are", "i"
        ])
        word_counts: Counter[str] = Counter()
        with self._lock:
            for event in self.data.get("events", []):
                words = re.findall(r"\b[\w']+\b", event.get("text", "").lower())
                word_counts.update(w for w in words if w not in stopwords)
        top_words = word_counts.most_common(5)
        return {
            "event_count": len(self.data.get("events", [])),
            "top_words": top_words,
        }