"""
Usage tracker
=============

This module implements a simple usage tracker for skills.  Each time a
skill is executed, its name is recorded in the persistent memory via
`MemoryHandler`.  Usage counts can be used to adjust skill priorities
over time.  A lower priority value means the skill runs earlier.
"""

from __future__ import annotations

import logging
from typing import Dict

from .memory_handler import MemoryHandler

logger = logging.getLogger(__name__)


class UsageTracker:
    """Track how often skills are run and adjust their priorities."""

    def __init__(self, memory_handler: MemoryHandler) -> None:
        self.memory_handler = memory_handler
        # Load existing usage counts from memory, or start with empty
        self._counts: Dict[str, int] = self.memory_handler.get("usage_counts", {}) or {}

    def record_usage(self, skill_name: str) -> None:
        """Increment the usage count for a skill and persist to memory."""
        self._counts[skill_name] = self._counts.get(skill_name, 0) + 1
        self.memory_handler.set("usage_counts", self._counts)
        logger.debug("Recorded usage of skill %s (count=%d)", skill_name, self._counts[skill_name])

    def adjust_priority(self, skill) -> None:
        """Adjust the priority of a skill based on its usage count.

        This simple strategy decreases the skill's priority value (higher
        priority) as it is used more frequently, with a lower bound of 1.
        """
        name = skill.metadata.get("name", skill.__class__.__name__)
        default_priority = skill.metadata.get("priority", 100)
        count = self._counts.get(name, 0)
        new_priority = max(1, default_priority - count)
        if new_priority != default_priority:
            logger.debug("Adjusting priority of skill %s: %d -> %d", name, default_priority, new_priority)
            skill.metadata["priority"] = new_priority

    def adjust_all(self, skills) -> None:
        """Adjust priorities for all skills in the given iterable."""
        for skill in skills:
            self.adjust_priority(skill)