"""
Skill base class
=================

This module defines the `BaseSkill` interface that all skills must
implement to be compatible with the Ada enhanced core.  A skill is a
self‑contained unit of functionality that can be loaded dynamically at
runtime.  Each skill should derive from `BaseSkill` and override the
`run()` method.  Optionally, a skill may expose metadata such as a
description and priority to influence scheduling.
"""

from __future__ import annotations

from typing import Any, Dict, Optional


class BaseSkill:
    """Base class for all skills.

    Subclasses should override the :meth:`run` method to perform their
    task.  A skill may maintain internal state across invocations.  The
    `metadata` attribute contains information used by the skill loader
    for scheduling and description.
    """

    #: Optional metadata dictionary describing the skill.  Keys include:
    #: ``name``: human‑readable name
    #: ``description``: a brief description of the skill
    #: ``priority``: lower values run earlier in the schedule
    metadata: Dict[str, Any] = {
        "name": "Unnamed skill",
        "description": "No description provided",
        "priority": 100,
    }

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        """Initialise the skill.

        :param config: Optional skill‑specific configuration dictionary
        """
        self.config = config or {}

    def run(self, *args: Any, **kwargs: Any) -> Optional[Any]:  # pragma: no cover
        """Execute the skill.

        Subclasses must implement this method.  It is called by the
        `SkillLoader` when the skill is scheduled to run.  It should
        return a result or None.  Exceptions should be handled
        internally or allowed to propagate to the caller.
        """
        raise NotImplementedError("Skills must implement the run() method")

    def __repr__(self) -> str:
        return f"<Skill {self.metadata.get('name', self.__class__.__name__)}>"