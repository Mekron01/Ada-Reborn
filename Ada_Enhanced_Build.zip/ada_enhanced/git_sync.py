"""
GitHub synchronization script
============================

This script provides a helper function to synchronise the local Ada
project with a remote Git repository.  It wraps Git commands to add
changes, commit them with a timestamped message and push to the
configured remote and branch.  Authentication (SSH keys or tokens)
must already be set up externally.

Usage:

    from ada_enhanced.git_sync import git_sync
    git_sync(path_to_repo, remote_name="origin", branch="main")

If `enable_git_sync` is disabled in the configuration, you can call
this function manually when needed.
"""

from __future__ import annotations

import datetime
import logging
import os
import subprocess
from typing import Optional

logger = logging.getLogger(__name__)


def git_sync(repo_path: str, remote_name: str = "origin", branch: str = "main",
             message: Optional[str] = None) -> None:
    """Synchronise the local Git repository with the remote.

    :param repo_path: Path to the Git repository
    :param remote_name: Name of the remote to push to
    :param branch: Branch to push
    :param message: Optional commit message; if None a timestamped
        default will be used
    """
    def run(cmd: list[str]) -> str:
        logger.debug("Running git command: %s", " ".join(cmd))
        result = subprocess.run(cmd, cwd=repo_path, capture_output=True, text=True)
        if result.returncode != 0:
            logger.error("Git command failed: %s", result.stderr.strip())
        return result.stdout.strip()

    # Stage changes
    run(["git", "add", "."])
    # Commit
    commit_message = message or f"Auto‑sync on {datetime.datetime.utcnow().isoformat()}"
    run(["git", "commit", "-m", commit_message])
    # Push
    run(["git", "push", remote_name, branch])
    logger.info("Synced repository %s to %s/%s", repo_path, remote_name, branch)