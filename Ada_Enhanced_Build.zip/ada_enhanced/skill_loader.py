"""
Skill loading and prioritization
===============================

The `SkillLoader` class is responsible for discovering, loading and
prioritising skills from the configured skills directory.  It scans
Python files in the skills directory, imports them as modules and
searches for classes derived from :class:`BaseSkill`.  Each skill
instance is initialised with the global configuration or skill‑specific
settings.

This module avoids executing arbitrary code on import by using
`importlib.machinery.SourceFileLoader` to load modules in an isolated
namespace.  Only classes deriving from `BaseSkill` are instantiated.

Note: in an untrusted environment, avoid placing untrusted code in the
skills directory.  Consider sandboxing or vetting third‑party skills
before use.
"""

from __future__ import annotations

import importlib.machinery
import inspect
import logging
import os
from types import ModuleType
from typing import Any, Dict, Iterable, List, Type

from .skill_base import BaseSkill

logger = logging.getLogger(__name__)


class SkillLoader:
    """Discover and manage skills.

    The loader scans a directory for Python files, imports them and
    instantiates classes derived from :class:`BaseSkill`.  Skills are
    stored in a list sorted by their priority (lower values first).
    """

    def __init__(self, skills_dir: str, config: Dict[str, Any] | None = None) -> None:
        self.skills_dir = skills_dir
        self.config = config or {}
        self.skills: List[BaseSkill] = []

    def discover(self) -> None:
        """Discover skill modules and instantiate skill classes.

        Raises an exception if a skill fails to import or initialise.
        """
        self.skills.clear()
        if not os.path.isdir(self.skills_dir):
            logger.warning("Skills directory %s does not exist", self.skills_dir)
            return
        for filename in os.listdir(self.skills_dir):
            if not filename.endswith(".py") or filename.startswith("__"):
                continue
            path = os.path.join(self.skills_dir, filename)
            try:
                skill_module = self._load_module(path)
            except Exception as exc:
                logger.exception("Failed to import skill module %s: %s", path, exc)
                continue
            for skill_class in self._iter_skill_classes(skill_module):
                try:
                    instance = skill_class(config=self.config)
                    self.skills.append(instance)
                    logger.info("Loaded skill %s (priority %s)",
                                instance.metadata.get("name", skill_class.__name__),
                                instance.metadata.get("priority", 100))
                except Exception as exc:
                    logger.exception("Failed to instantiate skill %s: %s",
                                    skill_class.__name__, exc)
        # sort by priority (lower number = higher priority)
        self.skills.sort(key=lambda s: s.metadata.get("priority", 100))

    def _load_module(self, path: str) -> ModuleType:
        """Load a module from a file path without caching it globally."""
        module_name = os.path.splitext(os.path.basename(path))[0]
        loader = importlib.machinery.SourceFileLoader(module_name, path)
        spec = importlib.util.spec_from_loader(loader.name, loader)
        assert spec is not None
        module = importlib.util.module_from_spec(spec)
        loader.exec_module(module)  # type: ignore[call-arg]
        return module

    def _iter_skill_classes(self, module: ModuleType) -> Iterable[Type[BaseSkill]]:
        """Yield classes in ``module`` that subclass :class:`BaseSkill`."""
        for _, obj in inspect.getmembers(module, inspect.isclass):
            if issubclass(obj, BaseSkill) and obj is not BaseSkill:
                yield obj

    def run_all(self) -> None:
        """Execute all loaded skills in order.

        Any exceptions raised by individual skills are logged and do not
        stop the execution of subsequent skills.
        """
        for skill in self.skills:
            try:
                logger.debug("Running skill %s", skill)
                skill.run()
            except Exception:
                logger.exception("Error while running skill %s", skill)