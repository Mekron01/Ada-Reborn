"""
Persona manager
===============

The `PersonaManager` maintains the current persona used by Ada and
provides functionality to switch between available personas at runtime.
Personas can affect the style and tone of responses and may alter
behaviour depending on context.  Each persona is defined by a name and
optional metadata such as a description.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class Persona:
    name: str
    description: str = ""

    def __repr__(self) -> str:
        return f"Persona(name={self.name!r}, description={self.description!r})"


class PersonaManager:
    """Manage available personas and the current persona."""

    def __init__(self, personas: List[Dict[str, str]], default_persona: str) -> None:
        self.personas: Dict[str, Persona] = {
            p["name"]: Persona(name=p["name"], description=p.get("description", ""))
            for p in personas
        }
        if default_persona not in self.personas:
            raise ValueError(f"Default persona {default_persona!r} not found in persona list")
        self.current: Persona = self.personas[default_persona]
        logger.info("Initial persona set to %s", self.current.name)

    def get_current(self) -> Persona:
        return self.current

    def switch_to(self, name: str) -> Persona:
        """Switch to a different persona by name.  If the name is not
        recognised the current persona remains unchanged."""
        if name not in self.personas:
            logger.warning("Requested persona %s not found; staying with %s", name, self.current.name)
            return self.current
        if name == self.current.name:
            logger.debug("Already using persona %s", name)
            return self.current
        self.current = self.personas[name]
        logger.info("Persona switched to %s", self.current.name)
        return self.current

    def list_personas(self) -> List[Persona]:
        """Return a list of all available personas."""
        return list(self.personas.values())