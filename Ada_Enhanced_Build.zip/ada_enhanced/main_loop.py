"""
Main loop
=========

This module defines the high‑level loop for the Ada enhanced core.  It
initialises subsystems such as the persona manager, memory handler,
skill loader, orb core and reflex core based on configuration, then
enters a loop where it periodically runs skills, monitors system
health and plans actions.

The loop can be interrupted by external signals (e.g. Ctrl+C).  On
shutdown, it ensures that memory is persisted to disk and resources
are cleaned up.
"""

from __future__ import annotations

import json
import logging
import os
import signal
import sys
import threading
import time
from dataclasses import dataclass
from typing import Any, Dict

try:
    import psutil  # type: ignore[import]
except ImportError:
    psutil = None  # type: ignore[assignment]

from .memory_handler import MemoryHandler
from .orb_core import OrbCore
from .persona_manager import PersonaManager
from .reflex_core import ReflexCore
from .skill_loader import SkillLoader

logger = logging.getLogger(__name__)


@dataclass
class HealthSettings:
    interval: int
    cpu_threshold: float
    memory_threshold: float


class AdaCore:
    """Coordinate the subsystems and run the main loop."""

    def __init__(self, config_path: str) -> None:
        self.config_path = config_path
        self.config: Dict[str, Any] = {}
        self._load_config()

        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )

        # Initialise subsystems
        personas_cfg = self.config.get("personas", [])
        default_persona = self.config.get("default_persona", "default")
        self.persona_manager = PersonaManager(personas_cfg, default_persona)

        memory_file = self.config.get("memory_file", "data/memory_store.json")
        self.memory_handler = MemoryHandler(memory_file)

        skills_dir = self.config.get("skills_dir", "skills")
        # Inject runtime objects into config for skills to access (e.g. memory)
        injected_config = dict(self.config)
        injected_config["_memory_handler"] = self.memory_handler
        self.skill_loader = SkillLoader(skills_dir, config=injected_config)

        self.orb_core = OrbCore()
        self.reflex_core = ReflexCore()

        # Register reflex handler for emergencies
        self.reflex_core.register_handler(self._handle_reflex)

        # Health settings
        hm = self.config.get("health_monitor", {})
        self.health_settings = HealthSettings(
            interval=int(hm.get("interval", 60)),
            cpu_threshold=float(hm.get("cpu_threshold", 95)),
            memory_threshold=float(hm.get("memory_threshold", 95)),
        )
        self._stop_event = threading.Event()

    def _load_config(self) -> None:
        """Load the configuration from disk."""
        if not os.path.exists(self.config_path):
            raise FileNotFoundError(f"Configuration file {self.config_path} does not exist")
        try:
            with open(self.config_path, "r", encoding="utf-8") as f:
                # JSON5 comments are ignored by simple json.load, but we strip // comments manually
                content = f.read()
                # Remove double slash comments
                lines = [line for line in content.splitlines() if not line.strip().startswith("//")]
                self.config = json.loads("\n".join(lines))
        except Exception as exc:
            raise RuntimeError(f"Failed to load config {self.config_path}: {exc}")

    def _handle_reflex(self, message: str) -> None:
        """Called when an emergency reflex is triggered."""
        logger.error("Emergency reflex: %s", message)
        # Persist memory on emergency
        self.memory_handler.save()
        # Additional handling such as notifying the user could be added here

    def _monitor_health(self) -> None:
        """Periodically check system health metrics and trigger reflexes if necessary."""
        if not psutil:
            logger.warning("psutil not available; health monitoring disabled")
            return
        while not self._stop_event.is_set():
            cpu = psutil.cpu_percent(interval=1)
            mem = psutil.virtual_memory().percent
            logger.debug("System health: CPU=%.1f%%, MEM=%.1f%%", cpu, mem)
            self.reflex_core.check_health(
                cpu_percent=cpu,
                memory_percent=mem,
                cpu_threshold=self.health_settings.cpu_threshold,
                memory_threshold=self.health_settings.memory_threshold,
            )
            # wait for the remainder of the interval
            time.sleep(max(0, self.health_settings.interval - 1))

    def run(self) -> None:
        """Run the main loop until interrupted."""
        # Discover skills
        self.skill_loader.discover()

        # Start health monitor thread if enabled
        if self.config.get("health_monitor", {}).get("enable_health_watchdog", False):
            thread = threading.Thread(target=self._monitor_health, daemon=True)
            thread.start()
            logger.info("Health monitor started (interval %ss)", self.health_settings.interval)

        # Handle Ctrl+C gracefully when running in the main thread
        def _sigint_handler(signum, frame):
            logger.info("Interrupt received; shutting down...")
            self.stop()
        # Signal handlers can only be set in the main thread
        if threading.current_thread() is threading.main_thread():
            signal.signal(signal.SIGINT, _sigint_handler)

        # Main loop
        try:
            while not self._stop_event.is_set():
                # Run all skills
                self.skill_loader.run_all()
                # Example: plan an action based on current persona or context
                context = {"persona": self.persona_manager.get_current().name, "goal": "idle"}
                action = self.orb_core.plan_action(context)
                logger.debug("Planned action: %s", action)
                # Wait before next iteration
                time.sleep(1)
        finally:
            # Persist memory before exiting
            self.memory_handler.save()
            logger.info("Ada core shut down cleanly")

    def stop(self) -> None:
        """Signal the main loop to stop."""
        self._stop_event.set()