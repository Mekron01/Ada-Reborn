"""
Reflex core
===========

The `ReflexCore` monitors the system for emergency conditions and
triggers reflexive responses when necessary.  It can be integrated
with a health monitor to detect high CPU or memory usage, or used to
catch specific runtime errors.  When a reflex is triggered it may
invoke a handler to initiate a safe shutdown, switch personas, or
take other corrective action.
"""

from __future__ import annotations

import logging
from typing import Callable, Optional

logger = logging.getLogger(__name__)


class ReflexCore:
    """Detect emergency conditions and execute reflexes."""

    def __init__(self) -> None:
        # A custom reflex handler can be registered.  It should accept
        # a message string describing the condition and perform
        # appropriate actions (e.g. cleanup, logging, notifying the user).
        self.reflex_handler: Optional[Callable[[str], None]] = None

    def register_handler(self, handler: Callable[[str], None]) -> None:
        """Set a handler to be invoked when a reflex is triggered."""
        self.reflex_handler = handler

    def trigger(self, message: str) -> None:
        """Invoke the reflex handler with the given message."""
        logger.warning("Reflex triggered: %s", message)
        if self.reflex_handler:
            try:
                self.reflex_handler(message)
            except Exception:
                logger.exception("Reflex handler raised an exception")

    def check_health(self, cpu_percent: float, memory_percent: float,
                     cpu_threshold: float, memory_threshold: float) -> None:
        """Check health metrics and trigger reflexes if thresholds are exceeded."""
        if cpu_percent > cpu_threshold:
            self.trigger(f"CPU usage too high ({cpu_percent:.1f}% > {cpu_threshold}%)")
        if memory_percent > memory_threshold:
            self.trigger(f"Memory usage too high ({memory_percent:.1f}% > {memory_threshold}%)")