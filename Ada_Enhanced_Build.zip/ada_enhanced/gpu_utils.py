"""
GPU utilities
=============

This module provides helper functions for working with GPUs and
Torch‑TensorRT.  If Torch‑TensorRT and the necessary CUDA libraries
are available, models can be compiled to TensorRT for accelerated
inference.  If not, the functions gracefully fall back to standard
PyTorch execution.

These utilities are optional and are only used when the `gpu.enable_tensorrt`
configuration option is set to true and when PyTorch is installed.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

try:
    import torch  # type: ignore
    from torch import nn  # type: ignore
except ImportError:
    torch = None  # type: ignore
    nn = None  # type: ignore

try:
    import torch_tensorrt  # type: ignore
except ImportError:
    torch_tensorrt = None  # type: ignore


def is_gpu_available() -> bool:
    """Return True if a CUDA GPU is available to PyTorch."""
    return bool(torch and torch.cuda.is_available())


def compile_model(model: Any, inputs: list[Any]) -> Any:
    """Compile a PyTorch model using Torch‑TensorRT if available.

    :param model: The PyTorch model (nn.Module) to compile
    :param inputs: A list of example inputs used for tracing/compiling
    :returns: A compiled model if TensorRT is available, otherwise the
        original model
    """
    if not torch or not nn:
        logger.warning("PyTorch not installed; cannot compile model")
        return model
    if not torch_tensorrt:
        logger.info("Torch‑TensorRT not available; using original PyTorch model")
        return model
    if not is_gpu_available():
        logger.info("No CUDA GPU available; using original PyTorch model")
        return model
    try:
        model.eval().cuda()
        compiled = torch.compile(model, backend="tensorrt")  # type: ignore[call-arg]
        logger.info("Compiled model with Torch‑TensorRT")
        # Run once to compile
        compiled(*[i.cuda() for i in inputs])
        return compiled
    except Exception as exc:
        logger.exception("Failed to compile model with Torch‑TensorRT: %s", exc)
        return model