"""Skill package for Ada enhanced.

Importing this package registers available skills.  Skills are
discovered dynamically by :class:`~ada_enhanced.skill_loader.SkillLoader`.
"""