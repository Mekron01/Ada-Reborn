"""
Hello skill
===========

This is a simple example skill that logs a greeting and appends an
event to the memory store.  It demonstrates how to use the
:class:`BaseSkill` API.  Skills can access the global configuration via
``self.config``.
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

from ada_enhanced.memory_handler import MemoryHandler
from ada_enhanced.skill_base import BaseSkill

logger = logging.getLogger(__name__)


class HelloSkill(BaseSkill):
    metadata = {
        "name": "HelloSkill",
        "description": "Logs a greeting and stores it in memory",
        "priority": 10,
    }

    def run(self) -> Any:
        # Access the global configuration
        greeting = self.config.get("hello_greeting", "Hello from Ada!")
        timestamp = datetime.utcnow().isoformat()
        message = f"{greeting} at {timestamp}"
        logger.info(message)
        # Append to memory if a MemoryHandler has been injected into config
        mem: MemoryHandler | None = self.config.get("_memory_handler")
        if mem:
            mem.add_event(message)
        return message